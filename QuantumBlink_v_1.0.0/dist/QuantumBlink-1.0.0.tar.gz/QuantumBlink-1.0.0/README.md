# QuantumBlink
### This library can be used to analyze intermittency data from quantum dots. 
